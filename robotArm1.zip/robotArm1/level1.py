from RobotArm import RobotArm

robotArm = RobotArm('assessment1')
robotArm.speed=1

# Jouw python instructies zet je vanaf hier:



# Na jouw code wachten tot het sluiten van de window:
robotArm.wait()